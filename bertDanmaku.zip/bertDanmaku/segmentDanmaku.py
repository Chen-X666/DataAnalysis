import re

import requests as requests

import jieba
# import hanlp
# HanLP = hanlp.load(hanlp.pretrained.mtl.UD_ONTONOTES_TOK_POS_LEM_FEA_NER_SRL_DEP_SDP_CON_XLMR_BASE)

def preprocess_text(content_lines, sentences):
    for line in content_lines:
        #if len(line)>4:
            try:
                segs = jieba.lcut(line)
                # segs = HanLP(line)['tok'] # Hanlp分词
                #segs = [v for v in segs if not str(v).isdigit()]  # 去数字
                segs = list(filter(lambda x: x.strip(), segs))  # 去左右空格
                segs = list(filter(lambda x: len(x) > 1, segs))  # 长度为1的字符
                # segs = list(filter(lambda x: x not in stopwordslist(), segs))  # 去掉停用词
                # print(segs)
                if len(segs) >2:
                    sentences.append(" ".join(segs))
            except Exception:
                # print(line)
                continue

if __name__ == '__main__':
    with open('test_dataset.txt', 'r') as f:
        textList = f.read().split('\n')
    sentences = []
    preprocess_text(textList, sentences)
    print(sentences)

